<?php

echo "Hello, World from php in Docker! <br>";
echo '<img src="https://www.docker.com/sites/default/files/horizontal.png">';

?>
